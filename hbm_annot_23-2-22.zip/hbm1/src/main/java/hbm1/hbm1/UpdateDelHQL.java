package hbm1.hbm1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class UpdateDelHQL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StandardServiceRegistry objSSR = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata metaobj= new MetadataSources(objSSR).getMetadataBuilder().build();
		SessionFactory factory = metaobj.getSessionFactoryBuilder().build();
		Session objse = factory.openSession();
		Transaction tranObj = objse.beginTransaction();
		
		Student objST = new Student();
		
		/*Query objQuery = objse.createQuery("update Student set sname=:sn where id=:i");
		objQuery.setParameter("sn", "Lavish kakad");
		objQuery.setParameter("i", 103); */
		
		Query objQuery = objse.createQuery("delete from Student where id=:i");
		 
		objQuery.setParameter("i", 101);
		int status=objQuery.executeUpdate();
		System.out.println(status);
		tranObj.commit();
		
	}

}
