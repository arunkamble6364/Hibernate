package hbm1.hbm1;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class SelectCmd {

	public static void main(String[] args) {
		StandardServiceRegistry objSSR = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata metaobj= new MetadataSources(objSSR).getMetadataBuilder().build();
		SessionFactory factory = metaobj.getSessionFactoryBuilder().build();
		Session objse = factory.openSession();
		Transaction tranObj = objse.beginTransaction();
		
		Student objST = new Student();
		
		Query objQuery = objse.createQuery("from Student");
		/*  objQuery.setFirstResult(2);
		  objQuery.setMaxResults(2); */
		// this can be used to provide pagination 
		List studentList = objQuery.list();
		Iterator itr = studentList.iterator();
		while(itr.hasNext())
		{
			objST =(Student)itr.next();
			System.out.println(objST.getSid()+"---"+objST.getSname());			
		}
		factory.close();
		objse.close();

	}

}
