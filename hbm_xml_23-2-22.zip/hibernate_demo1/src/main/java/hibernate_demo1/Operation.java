package hibernate_demo1;

import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
public class Operation {

	public static void main (String s[])
	{
		StandardServiceRegistry objSSR = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata metaobj= new MetadataSources(objSSR).getMetadataBuilder().build();
		SessionFactory factory = metaobj.getSessionFactoryBuilder().build();
		Session objse = factory.openSession();
		Transaction tranObj = objse.beginTransaction();
		
		Student objST = new Student();
		//objST.setSid(101);
		objST.setAddress("12/2 mig colony ");
		
		objST.setSname("vijay kumar");
		objST.setClassname("M Tech");
		// when we provide generator class as assigned we need to give values for primary key column
		objse.save(objST);
		
		
		tranObj.commit();
		System.out.println("record saved");
		factory.close();
		objse.close();
		
	}
}
