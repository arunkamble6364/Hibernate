package hbm1.hbm1;

import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import java.util.Scanner;
public class Operation {

	public static void main (String s[])
	{
		int ch=1;
		int id;
		String name,cname,address;
		StandardServiceRegistry objSSR = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata metaobj= new MetadataSources(objSSR).getMetadataBuilder().build();
		SessionFactory factory = metaobj.getSessionFactoryBuilder().build();
		Session objse = factory.openSession();
		Transaction tranObj = objse.beginTransaction();
		
		Student objST = new Student();
		
		Scanner sc = new Scanner(System.in);
		while(ch!=0)
		{
			System.out.println("Enter id=");
			id=sc.nextInt();
			System.out.println("Enter name=");
			name=sc.nextLine();
			System.out.println("Enter address=");
			address=sc.nextLine();
			System.out.println("Enter classname=");
			cname=sc.nextLine();
			objST.setSid(id);
			objST.setAddress(address);
			
			objST.setSname(name);
			objST.setClassname(cname);
			// when we provide generator class as assigned we need to give values for primary key column
			objse.save(objST);
			tranObj.commit();
			System.out.println("record saved");
			System.out.println("1 for insert 2 for exit");
			ch= sc.nextInt();
		}
		objST.setSid(102);
		objST.setAddress("anand nagar");
		
		objST.setSname("vinod kumar");
		objST.setClassname("M Tech");
		// when we provide generator class as assigned we need to give values for primary key column
		objse.save(objST);
		tranObj.commit();
		System.out.println("record saved");
		factory.close();
		objse.close();		
	}
}
